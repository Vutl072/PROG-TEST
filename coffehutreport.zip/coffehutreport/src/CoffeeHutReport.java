public class CoffeeHutReport {

    public static void main(String[] args) {

        // Single-dimensional array for city names
        String[] cities = {
            "Cape Town",
            "Port Elizabeth",
            "Pretoria"
        };

        // Two-dimensional array for beverage sales
        // Coffee, Tea, Boba Tea
        int[][] sales = {
            {500, 300, 125},
            {450, 250, 100},
            {480, 175, 120}
        };

        int grandTotal = 0;

        // Display report heading
        System.out.println("NUMBER 1 COFFEE HUT");
        System.out.println("MONTHLY BEVERAGE SALES REPORT");
        System.out.println("----------------------------------------------------------");
        System.out.printf("%-18s %10s %10s %10s %10s%n",
                "City", "Coffee", "Tea", "Boba Tea", "Total");
        System.out.println("----------------------------------------------------------");

        // Calculate and display sales for each city
        for (int i = 0; i < cities.length; i++) {

            int cityTotal = 0;

            for (int j = 0; j < sales[i].length; j++) {
                cityTotal += sales[i][j];
            }

            grandTotal += cityTotal;

            System.out.printf("%-18s %10d %10d %10d %10d%n",
                    cities[i],
                    sales[i][0],
                    sales[i][1],
                    sales[i][2],
                    cityTotal);
        }

        System.out.println("----------------------------------------------------------");
        System.out.println("Total sales for all cities: " + grandTotal);
    }
}
    
            
   
    

