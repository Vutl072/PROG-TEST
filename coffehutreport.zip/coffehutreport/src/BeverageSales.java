public class BeverageSales extends Beverage {

    public BeverageSales(String beverageType, String city,
                         int totalSales) {
        super(beverageType, city, totalSales);
    }

    public void printReport() {

        System.out.println();
        System.out.println("NUMBER 1 COFFEE HUT REPORT");
        System.out.println("***********************");
        System.out.println("BEVERAGE TYPE: "
                + getBeverageType());
        System.out.println("CITY: " + getCity());
        System.out.println("TOTAL SALES: "
                + getTotalSales());
    }
}
